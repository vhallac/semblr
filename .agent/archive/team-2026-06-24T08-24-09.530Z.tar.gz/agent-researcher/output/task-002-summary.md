# Issue #86 Summary — Multi-Model Routing for Semblr

**Source:** Issue by vhallac (OWNER) | **Date:** 2026-06-23 | **Status:** Open, no comments

---

## Core Proposal

LLM self-reports its "generation phase" via a new semblr tool. Semblr intercepts the call and routes to a different model (faster/cheaper/stronger) based on the reported phase. Inspired by sakana.ai's TRINITY, but uses the LLM itself as classifier instead of a separate network.

## Proposed Phases

| Phase | Action |
|---|---|
| `exploring` | Keep on current model |
| `executing` | Switch to faster/cheaper Worker |
| `stuck` | Escalate to stronger model |
| `verifying` | Cross-check with different model |
| `done` | Collapse chain |

Plus a "note to future self" parameter for inter-model context passing.

## Architectural Fit

- **Good:** Extends existing patterns — tool interception, context injection, follow-up flagging
- **Good:** Symmetrical to how semblr already injects prompts at context thresholds
- **Concern:** Conflicts with "framework-lean" principle (adds model registry, routing rules, phase taxonomy)
- **Not on roadmap:** Would be Phase 6 or a Phase 5 sub-item

## Risks (Author-acknowledged)

| Risk | Severity |
|---|---|
| No prior art — LLM self-assessment may fail entirely | HIGH |
| Weaker models may get stuck in `exploring` | HIGH |
| pi may not support mid-session model switching | HIGH |
| Every switch = uncached tokens = higher cost | MEDIUM |
| Potential infinite routing loops | MEDIUM |

## Precedent in Semblr

`round_needs_followup` already passes metadata across round boundaries (detect marker → set flag → next round injects context → clear flag). Same pattern could carry "note to future self."

## Critical Unknowns (Blocking)

1. **pi model-switching API** — Can models change mid-session? If not, requires SDK changes or subprocess workaround
2. **Phase detection accuracy** — Zero empirical data
3. **User experience** — Transparent or announced switches?
4. **Loop prevention** — What stops infinite routing chains?

## Assessment

Conceptual proposal, not an implementation plan. Author fully aware of risks. Feasible only if pi supports mid-session model switching. Conservative first step: 2 phases only (`execute` → `done`).
